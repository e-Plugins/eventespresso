<?php
printf(
    esc_html__('You need a Digiwallet account to use this plugin. Sign up on', 'digiwallet') .
    ' <a href="https://www.digiwallet.nl" target="_blank">https://www.digiwallet.nl</a>'
);