<?php
;// Silence is golden.
