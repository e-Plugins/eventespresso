=== Event Espresso - Digiwallet (EE 4.x+) ===
Contributors: digiwallet.nl
Tags: gateway, event espresso, eventespresso, event-espresso-digiwallet, digiwallet
Requires at least: 1.0.0
Tested up to: 4.10.6decaf
