<?php
printf(
    esc_html__('You need a TargetPay account to use this plugin. Sign up on', 'event_espresso') .
    ' <a href="http://www.targetpay.com" target="_blank">TargetPay.com</a>' .
    esc_html__('. You can use promotional code YM3R2A for a reduced iDEAL price...', 'event_espresso')
);